为减少文件大小删除了images、data、models下内容。。。

数据集下载地址：
官网：http://vision.stanford.edu/aditya86/ImageNetDogs/main.html 
超星云（推荐）：http://d0.ananas.chaoxing.com/download/8419b42166374e6c3ae8808168cc9c44?fn=images 
images压缩包内容放到相应images文件夹下

data下载地址：
http://d0.ananas.chaoxing.com/download/8eef90454668813c187359c4d8e8a4a4?fn=data  
data压缩包内容放到相应data文件夹下。

models下载地址：
http://d0.ananas.chaoxing.com/download/40dd3c98429eea9158d8c2c36bb62bd7?fn=models 
models压缩包内容放到相应models文件夹下


keras模型参数下载地址:
http://d0.ananas.chaoxing.com/download/957fa6655df1b80d08347b4f669706ea?fn=kerasModels 
kerasModel压缩包内容放到C:\Users\用户名\.keras\models下。

