data下载地址：
http://d0.ananas.chaoxing.com/download/8eef90454668813c187359c4d8e8a4a4?fn=data  
data压缩包内容放到相应data文件夹下。