数据集下载地址：
官网：http://vision.stanford.edu/aditya86/ImageNetDogs/main.html 
超星云（推荐）：http://d0.ananas.chaoxing.com/download/8419b42166374e6c3ae8808168cc9c44?fn=images 
images压缩包内容放到相应images文件夹下