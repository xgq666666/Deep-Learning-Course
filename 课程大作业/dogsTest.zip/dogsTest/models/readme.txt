models下载地址：
http://d0.ananas.chaoxing.com/download/40dd3c98429eea9158d8c2c36bb62bd7?fn=models 
models压缩包内容放到相应models文件夹下


keras模型参数下载地址:
http://d0.ananas.chaoxing.com/download/957fa6655df1b80d08347b4f669706ea?fn=kerasModels 
kerasModel压缩包内容放到C:\Users\用户名\.keras\models下。